import express from "express";
import Video from "../models/Video.js";

const router = express.Router();

router.get("/search", async (req, res) => {
  try {
    const { q } = req.query;

    if (!q) {
      return res.status(400).json({ message: "Search query is required" });
    }

    const videos = await Video.find({
      title: { $regex: q, $options: "i" },
    });

    res.json(videos);
  } catch (err) {
    console.error("Search error:", err);
    res.status(500).json({ message: "Server error during search" });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const video = await Video.findById(req.params.id);
    if (!video) return res.status(404).json({ message: "Video not found" });
    res.json(video);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

router.put('/:id/like', async (req, res) => {
  try {
    const video = await Video.findByIdAndUpdate(
      req.params.id,
      { $inc: { likes: 1 } },
      { new: true }
    );
    res.json(video);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

router.put('/:id/dislike', async (req, res) => {
  try {
    const video = await Video.findByIdAndUpdate(
      req.params.id,
      { $inc: { dislikes: 1 } },
      { new: true }
    );
    res.json(video);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

router.put('/:id/unlike', async (req, res) => {
  try {
    const video = await Video.findByIdAndUpdate(
      req.params.id,
      { $inc: { likes: -1 } },
      { new: true }
    );
    res.json(video);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

router.put('/:id/undislike', async (req, res) => {
  try {
    const video = await Video.findByIdAndUpdate(
      req.params.id,
      { $inc: { dislikes: -1 } },
      { new: true }
    );
    res.json(video);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

router.post('/:id/comments', async (req, res) => {
  try {
    const video = await Video.findByIdAndUpdate(
      req.params.id,
      { $push: { comments: req.body } },
      { new: true }
    );
    res.status(201).json(video.comments[video.comments.length - 1]);
  } catch (err) {
    res.status(500).json({ message: "Failed to add comment" });
  }
});

router.get('/', async (req, res) => {
  try {
    const videos = await Video.find()
    res.json(videos);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch videos" });
  }
});

export default router;